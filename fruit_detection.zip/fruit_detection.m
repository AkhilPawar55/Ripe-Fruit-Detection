function fruit_detection()
    image_file = 'ripe_unripe_tomatoes.jpg';
    im = imread(image_file);
    colorbar();
    %imshow(im);
    
    im_double = im2double(im);
    
    %Smooth the image
    % Create a gaussian filter
    hsize   =   9;
    sigma   =   3;
    h   =   fspecial('gaussian', hsize, sigma);
    
    % Apply local smearing using the gaussian filter
    im_blur   =   imfilter(im_double, h, 'same', 'repl');
    
    %Select appropriate color space
    
    im_R = im_blur(:,:,1);
    %figure();
    %imshow(im_R);
    colorbar();
    %title('Red');
    
    im_hsv = rgb2hsv(im_blur);
    %figure();
    %imshow(im_hsv);
    colorbar();
    %title('HSV');
    
    im_s = im_hsv(:,:,2);
    %figure();
    %imshow(im_s);
    colorbar();
    %title('Saturation');
    
    im_h = im_hsv(:,:,1);
    %figure();
    %imshow(im_h);
    %colorbar();
    %title('Hue');
    
    im_lab = rgb2lab(im_blur);
    %figure();
    %imshow(im_lab);
    %colorbar();
    %title('LAB');
    
    im_a = im_lab(:,:,2);
    %figure();
    %imshow(im_a);
    colorbar();
    %title('A');
    
    im_ycbcr = rgb2ycbcr(im_blur);
    %figure();
    %imshow(im_ycbcr);
    colorbar();
    %title('YcBcR');
    
    im_cR = im_ycbcr(:,:,3);
    %figure();
    %imshow(im_cR);
    colorbar();
    %title('Red');
    
    im_yiq = rgb2ntsc(im_blur);
    %figure();
    %imshow(im_yiq);
    %colorbar();
    %title('YIQ');
    
    im_y = im_yiq(:,:,1);
    %figure();
    %imshow(im_y);
    colorbar();
    %title('Y');
  
    im_q = im_yiq(:,:,3);
    %figure();
    %imshow(im_q);
    %colorbar();
    %title('Q');
    
    im_i = im_yiq(:,:,2);
    imshow(im_i);
    colorbar();
    title('I');
    
    im_quant = zeros(size(im_i, 1), size(im_i, 2));
    for x = 1 : size(im_i, 1)
        for y = 1 : size(im_i, 2)
            if im_i(x, y) >= 0.12 && im_i(x, y) <= 0.15
                im_quant(x, y) = 0.0;
            end
            if im_i(x, y) >= 0.151 && im_i(x, y) <= 0.225
                im_quant(x, y) = 0.1;
            end
            if im_i(x, y) >= 0.25 && im_i(x, y) <= 1
                im_quant(x, y) = 0.7;
            end
        end
    end
    figure();
    imshow(im_quant);
    colorbar();
    title('Quant');
    
    im_quant = imbinarize(im_quant);
    
    el = [1 1 1 1 1
          1 1 1 1 1
          1 1 1 1 1
          1 1 1 1 1
          1 1 1 1 1];
    
    im_quant = imdilate(im_quant, el);
    im_quant = imdilate(im_quant, el);
    im_quant = imdilate(im_quant, el);
    im_quant = imdilate(im_quant, el);
    
    figure();
    imshow(im_quant);
    colorbar();
    title('Dilation');
    
    figure();
    imshow(im);
    colorbar();
    title('Ripe Fruit Detection');
    
    %Set the radius range for the bright circles in all the images
    bt_r_range_2 = [61 120];
    bt_r_range_3 = [121 220];
    
    
    [circles, radii] = imfindcircles(im_quant, bt_r_range_2, 'ObjectPolarity', 'bright', 'sensitivity', 0.95);
    viscircles(circles, radii, 'Edgecolor', 'g');
    
    [circles, radii] = imfindcircles(im_quant, bt_r_range_3, 'ObjectPolarity', 'bright', 'sensitivity', 0.95);
    viscircles(circles, radii, 'Edgecolor', 'g');
    
    L = watershed(im_quant);
    rgb = label2rgb(L, 'jet');
    figure();
    imshow(rgb);
    colorbar();
    title('Water Shed');
    
    %use DCT texture segmentation.
    % To do...
    
end